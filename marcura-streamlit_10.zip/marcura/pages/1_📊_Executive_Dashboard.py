import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd

from utils.style import inject_css, hub_selector, footer, kpi_card
from data.synthetic import get_kpis, get_monthly_emissions, get_suppliers, get_shipments, get_vessels

st.set_page_config(page_title="Executive Dashboard · Marcura", page_icon="📊", layout="wide")
inject_css()
hub = hub_selector()

st.markdown(f"## 📊 Executive Dashboard — {hub} Hub")
st.caption("Consolidated KPIs, emissions trend, and portfolio performance.")

kpis = get_kpis(hub)
monthly = get_monthly_emissions(hub)
suppliers = get_suppliers(hub, n=80 if hub != "Global" else 200)
shipments = get_shipments(hub, n=400 if hub != "Global" else 1200)
vessels = get_vessels(hub, n=60 if hub != "Global" else 150)

# ---------------- KPI ROW ----------------
row1 = st.columns(4)
with row1[0]:
    kpi_card("Total Scope 3", f"{kpis['total_scope3']:,.0f} tCO₂e", "3.2% vs target", positive=False)
with row1[1]:
    kpi_card("Monthly Emissions", f"{kpis['monthly_emissions']:,.0f} tCO₂e", "1.4% MoM", positive=False)
with row1[2]:
    kpi_card("Carbon Target", f"{kpis['carbon_target']:,.0f} tCO₂e")
with row1[3]:
    kpi_card("ESG Score (avg)", f"{kpis['esg_score']}", "2.1 pts", positive=True)

row2 = st.columns(4)
with row2[0]:
    kpi_card("Procurement Spend", f"${kpis['procurement_spend']/1e6:,.1f}M")
with row2[1]:
    kpi_card("Active Suppliers", f"{kpis['active_suppliers']:,}")
with row2[2]:
    kpi_card("Shipments", f"{kpis['shipments']:,}")
with row2[3]:
    kpi_card("Active Vessels", f"{kpis['vessels']:,}", f"avg {kpis['avg_speed']} kn")

st.write("")

# ---------------- CHARTS ----------------
c1, c2 = st.columns([1.4, 1])
with c1:
    st.markdown("#### Monthly Scope 3 Emissions Trend")
    fig = px.area(monthly, x="month", y="scope3_tco2e", template="plotly_dark")
    fig.update_traces(line_color="#22d3ee", fillcolor="rgba(34,211,238,0.15)")
    fig.update_layout(
        plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
        margin=dict(t=10, l=0, r=0, b=0), height=340,
    )
    st.plotly_chart(fig, use_container_width=True)

with c2:
    st.markdown("#### Emissions by Transport Mode")
    mode_df = shipments.groupby("mode")["co2e_tonnes"].sum().reset_index()
    fig2 = px.pie(mode_df, names="mode", values="co2e_tonnes", hole=0.55,
                  color_discrete_sequence=px.colors.sequential.Tealgrn)
    fig2.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", margin=dict(t=10, l=0, r=0, b=0), height=340,
        legend=dict(orientation="h", y=-0.1),
    )
    st.plotly_chart(fig2, use_container_width=True)

c3, c4 = st.columns(2)
with c3:
    st.markdown("#### Top 10 Suppliers by Emissions")
    top_sup = suppliers.sort_values("carbon_emissions_tco2e", ascending=False).head(10)
    fig3 = px.bar(top_sup, x="carbon_emissions_tco2e", y="name", orientation="h",
                  color="esg_score", color_continuous_scale="Teal")
    fig3.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(t=10, l=0, r=0, b=0), height=380, yaxis=dict(categoryorder="total ascending"),
    )
    st.plotly_chart(fig3, use_container_width=True)

with c4:
    st.markdown("#### Shipment Status Breakdown")
    status_df = shipments["status"].value_counts().reset_index()
    status_df.columns = ["status", "count"]
    fig4 = px.bar(status_df, x="status", y="count", color="status",
                  color_discrete_sequence=px.colors.qualitative.Set2)
    fig4.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(t=10, l=0, r=0, b=0), height=380, showlegend=False,
    )
    st.plotly_chart(fig4, use_container_width=True)

st.markdown("#### Shipment Register (sample)")
st.dataframe(
    shipments[["shipment_id", "origin", "destination", "mode", "status", "co2e_tonnes", "cost_usd", "eta"]].head(25),
    use_container_width=True, hide_index=True,
)

footer()
