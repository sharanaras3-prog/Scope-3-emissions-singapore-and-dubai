import streamlit as st
import pandas as pd
import plotly.graph_objects as go

from utils.style import inject_css, hub_selector, footer, kpi_card
from data.synthetic import get_suppliers, get_ports

st.set_page_config(page_title="Scope 3 Calculator · Marcura", page_icon="🧮", layout="wide")
inject_css()
hub = hub_selector()

st.markdown(f"## 🧮 Scope 3 Calculator — {hub} Hub")
st.caption("Estimate shipment-level Scope 3 emissions from transport parameters. "
           "Emission factors are illustrative, not audited.")

# Illustrative emission factors, gCO2e per tonne-km
EMISSION_FACTORS = {
    "Sea Freight": {"co2": 8.0, "ch4": 0.0004, "n2o": 0.0002, "carbon_cost_per_t": 45},
    "Air Freight": {"co2": 550.0, "ch4": 0.0006, "n2o": 0.0009, "carbon_cost_per_t": 90},
    "Road": {"co2": 62.0, "ch4": 0.0015, "n2o": 0.0012, "carbon_cost_per_t": 55},
    "Rail": {"co2": 22.0, "ch4": 0.0008, "n2o": 0.0006, "carbon_cost_per_t": 40},
    "Sea-Air": {"co2": 180.0, "ch4": 0.0005, "n2o": 0.0006, "carbon_cost_per_t": 70},
}

ports = get_ports(hub)
suppliers = get_suppliers(hub, n=80 if hub != "Global" else 200)
port_names = ports["name"].tolist()
supplier_names = suppliers["name"].tolist()

left, right = st.columns([1, 1.2])

with left:
    st.markdown("#### Shipment Parameters")
    with st.container():
        buyer = st.text_input("Buyer", "Marcura Client Co.")
        seller = st.text_input("Seller", "Global Trading Ltd.")
        supplier = st.selectbox("Supplier", supplier_names)
        c1, c2 = st.columns(2)
        with c1:
            origin = st.selectbox("Origin", port_names, index=0)
        with c2:
            destination = st.selectbox("Destination", port_names, index=min(1, len(port_names) - 1))
        mode = st.selectbox("Transport Mode", list(EMISSION_FACTORS.keys()))
        c3, c4 = st.columns(2)
        with c3:
            weight = st.number_input("Weight (tonnes)", min_value=0.1, value=25.0, step=0.5)
        with c4:
            distance = st.number_input("Distance (km)", min_value=1, value=5200, step=50)
        container_type = st.selectbox("Container Type", ["20ft Standard", "40ft Standard", "40ft High Cube", "Reefer", "Bulk / Break Bulk", "N/A (Air)"])
        fuel = st.selectbox("Fuel Type", ["HFO (Heavy Fuel Oil)", "MGO (Marine Gas Oil)", "LNG", "Diesel", "Jet A-1", "Electric"])

    calc = st.button("Calculate Emissions", type="primary", use_container_width=True)

with right:
    st.markdown("#### Results")
    if calc:
        ef = EMISSION_FACTORS[mode]
        tkm = weight * distance
        co2_kg = tkm * ef["co2"] / 1000
        ch4_kg = tkm * ef["ch4"]
        n2o_kg = tkm * ef["n2o"]
        # GWP: CH4=28, N2O=265 (AR5, illustrative)
        co2e_kg = co2_kg + (ch4_kg * 28) + (n2o_kg * 265)
        co2e_tonnes = co2e_kg / 1000
        carbon_cost = co2e_tonnes * ef["carbon_cost_per_t"]

        r1, r2 = st.columns(2)
        with r1:
            kpi_card("Total CO₂e", f"{co2e_tonnes:,.2f} t")
        with r2:
            kpi_card("Carbon Cost (est.)", f"${carbon_cost:,.0f}")

        r3, r4, r5 = st.columns(3)
        with r3:
            kpi_card("CO₂", f"{co2_kg:,.1f} kg")
        with r4:
            kpi_card("CH₄", f"{ch4_kg:,.3f} kg")
        with r5:
            kpi_card("N₂O", f"{n2o_kg:,.3f} kg")

        st.write("")
        fig = go.Figure(go.Bar(
            x=["CO₂ (as CO₂e)", "CH₄ (as CO₂e)", "N₂O (as CO₂e)"],
            y=[co2_kg, ch4_kg * 28, n2o_kg * 265],
            marker_color=["#22d3ee", "#a3e635", "#fb923c"],
        ))
        fig.update_layout(
            template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            height=300, margin=dict(t=10, l=0, r=0, b=0), yaxis_title="kg CO₂e",
        )
        st.plotly_chart(fig, use_container_width=True)

        st.markdown("#### Reduction Suggestions")
        suggestions = []
        if mode == "Air Freight":
            suggestions.append("Switching to Sea-Air could cut this shipment's emissions by roughly 65–70%.")
        if mode == "Road" and distance > 1000:
            suggestions.append("Rail is available on this lane and could reduce emissions by ~60%.")
        if fuel == "HFO (Heavy Fuel Oil)":
            suggestions.append("Vessel bunkering with LNG or biofuel blends could lower CO₂ intensity by 15–25%.")
        if weight < 5:
            suggestions.append("Consolidating with other shipments on this route could improve load factor and reduce per-unit emissions.")
        if not suggestions:
            suggestions.append("This shipment's mode and fuel choice are already relatively low-carbon for the given distance.")
        for s in suggestions:
            st.markdown(f"- {s}")

        st.caption(
            f"Route: **{origin} → {destination}** · Supplier: **{supplier}** · "
            f"Buyer/Seller: {buyer} / {seller} · Container: {container_type}"
        )
    else:
        st.info("Fill in shipment parameters on the left and click **Calculate Emissions**.")

footer()
