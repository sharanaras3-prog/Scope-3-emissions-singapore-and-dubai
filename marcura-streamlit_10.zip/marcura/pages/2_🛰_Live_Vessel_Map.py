import streamlit as st
import pydeck as pdk
import pandas as pd

from utils.style import inject_css, hub_selector, footer
from data.synthetic import get_vessels, get_ports, HUB_CONFIG

st.set_page_config(page_title="Live Vessel Map · Marcura", page_icon="🛰️", layout="wide")
inject_css()
hub = hub_selector()

st.markdown(f"## 🛰️ Live Vessel Map — {hub} Hub")
st.caption("Synthetic AIS-style fleet view. Positions, headings and emissions are simulated.")

vessels = get_vessels(hub, n=60 if hub != "Global" else 150)
ports = get_ports(hub)

# ---------------- FILTERS ----------------
f1, f2, f3, f4 = st.columns([1.3, 1, 1, 1])
with f1:
    search = st.text_input("🔍 Search vessel name", "")
with f2:
    vtypes = st.multiselect("Vessel type", sorted(vessels["type"].unique()))
with f3:
    min_speed, max_speed = st.slider("Speed (kn)", 0, 25, (0, 25))
with f4:
    show_ports = st.checkbox("Show ports", value=True)

filtered = vessels.copy()
if search:
    filtered = filtered[filtered["name"].str.contains(search, case=False)]
if vtypes:
    filtered = filtered[filtered["type"].isin(vtypes)]
filtered = filtered[(filtered["speed_kn"] >= min_speed) & (filtered["speed_kn"] <= max_speed)]

color_map = {
    "Container Ship": [34, 211, 238],
    "LPG Tanker": [248, 113, 113],
    "Bulk Carrier": [163, 230, 53],
    "Crude Tanker": [251, 146, 60],
    "RoRo": [167, 139, 250],
    "General Cargo": [148, 163, 184],
}
filtered["color"] = filtered["type"].map(color_map)

center = HUB_CONFIG[hub if hub in HUB_CONFIG else "Global"]["center"]
zoom = HUB_CONFIG[hub if hub in HUB_CONFIG else "Global"]["zoom"]

layers = []
layers.append(pdk.Layer(
    "ScatterplotLayer",
    data=filtered,
    get_position=["lon", "lat"],
    get_fill_color="color",
    get_radius=25000 if hub != "Global" else 60000,
    pickable=True,
    opacity=0.85,
))
if show_ports:
    layers.append(pdk.Layer(
        "ScatterplotLayer",
        data=ports,
        get_position=["lon", "lat"],
        get_fill_color=[250, 204, 21],
        get_radius=35000 if hub != "Global" else 90000,
        pickable=True,
        opacity=0.9,
    ))

tooltip = {
    "html": "<b>{name}</b><br/>Type: {type}<br/>Speed: {speed_kn} kn · Heading: {heading}°"
            "<br/>CO₂e: {co2e_tonnes} t",
    "style": {"backgroundColor": "#0b1220", "color": "#e5e7eb"},
}

deck = pdk.Deck(
    map_style="mapbox://styles/mapbox/dark-v11",
    initial_view_state=pdk.ViewState(latitude=center[0], longitude=center[1], zoom=zoom - 1, pitch=0),
    layers=layers,
    tooltip=tooltip,
)

st.pydeck_chart(deck, use_container_width=True, height=560)

st.write("")
st.markdown(f"**{len(filtered)} vessels matching filters** · {len(ports)} ports shown")

# ---------------- FLOATING VESSEL CARD ----------------
sel = st.selectbox(
    "Select a vessel for details",
    filtered["name"].tolist() if len(filtered) else [],
)
if sel:
    v = filtered[filtered["name"] == sel].iloc[0]
    st.markdown(
        f"""
        <div class="glass-card" style="max-width:640px;">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <div>
                    <div style="font-size:1.2rem; font-weight:700;">{v['name']}</div>
                    <div style="color:#94a3b8; font-size:0.85rem;">{v['type']}</div>
                </div>
                <span class="hub-pill">{v['status']}</span>
            </div>
            <hr style="border-color:rgba(255,255,255,0.08);">
            <div style="display:flex; gap:32px; flex-wrap:wrap;">
                <div><div class="kpi-label">Origin</div><div>{v['origin']}</div></div>
                <div><div class="kpi-label">Destination</div><div>{v['destination']}</div></div>
                <div><div class="kpi-label">ETA</div><div>{v['eta']}</div></div>
                <div><div class="kpi-label">Speed / Heading</div><div>{v['speed_kn']} kn / {v['heading']}°</div></div>
                <div><div class="kpi-label">Draught</div><div>{v['draught_m']} m</div></div>
                <div><div class="kpi-label">Fuel</div><div>{v['fuel_pct']}%</div></div>
                <div><div class="kpi-label">Est. CO₂e</div><div>{v['co2e_tonnes']} t</div></div>
                <div><div class="kpi-label">Carbon Intensity</div><div>{v['carbon_intensity_gco2_tkm']} gCO₂/t·km</div></div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

st.markdown("#### Fleet Table")
st.dataframe(
    filtered[["vessel_id", "name", "type", "status", "speed_kn", "heading", "origin", "destination",
              "eta", "co2e_tonnes"]],
    use_container_width=True, hide_index=True,
)

footer()
